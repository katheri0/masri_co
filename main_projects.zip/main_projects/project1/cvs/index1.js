let  masage= function()
{
    alert("Thank you for choosing US  ");
    
};
setTimeout(masage, 4000);
