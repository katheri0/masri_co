  let  masage= function()
{
    alert("i take the best photos   i hope to make a deal");
    
};
setTimeout(masage, 4000);



let  thanks= function()
{
    alert("thnaks i will do my best");
    
};
setTimeout(thanks, 7000);