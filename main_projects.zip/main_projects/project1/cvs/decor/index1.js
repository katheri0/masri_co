  let  masage= function()
{
    alert("decoring ?  you are in the right place ");
    
};
setTimeout(masage, 4000);



let  thanks= function()
{
    alert("thnaks by the way ");
    
};
setTimeout(thanks, 7000);