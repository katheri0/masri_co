  let  masage= function()
{
    alert("code will make you and i ritch ");
    
};
setTimeout(masage, 4000);



let  thanks= function()
{
    alert("lets do this");
    
};
setTimeout(thanks, 7000);
